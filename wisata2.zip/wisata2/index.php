<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/typed.js/2.0.11/typed.min.js"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script> -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" /> -->
</head>

<body>

    <div class="scroll-up-btn">
        <i class="fas fa-angle-up"></i>
    </div>
    <nav class="navbar">
        <div class="max-width">
            <div class="logo">
                <a href="index.php">
                    <img src="logo.png" alt="">
                </a>
            </div>
            <ul class="menu">
                <li><a href="#home" class="menu-btn">Home</a></li>
                <li><a href="#" class="menu-btn">About</a></li>
                <li><a href="#about" class="menu-btn">Bidang Pariwisata</a></li>
                <li><a href="#" class="menu-btn">Bidang Kebudayaan</a></li>
                <li><a href="#" class="menu-btn">Bidang Pemudaan Dan Olahraga</a></li>
                <li><a href="#" class="menu-btn">Informasi</a></li>
                <li><a href="\projectuas/" class="menu-btn">Login Admin</a></li>
            </ul>
            <div class="menu-btn">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </nav>

    <!-- home section start -->
    <section class="home" id="home">
        <div class="max-width">
            <div class="home-content">
                <div class="tex-1">
                    <font face="Langar" size="4">
                        <p>SELAMAT DATANG DI WEBSITE DINAS PEMUDA</p>
                    </font>
                    <font face="Langar" size="4">
                        <p>OLAHRAGA,PARIWISATAKEBUDAYAAN </p>
                    </font>
                    <font face="Langar" size="4">
                        <p>KABUPATEN PROBOLINGGO</p>
                    </font>
                </div>
                <div class="text-2">
                    PROBOLINGGO</div>
            </div>
            <div class="tex-3">
                <font face="Langar" size="4">
                    <p>Ayo berwisata di kabupaten Probolinggo, temukan kejutan dan nikmati</p>
                </font>
                <font face="Langar" size="4">
                    <p class="pariwisata">pesona alam, buatan, budaya, religi, dan minat khusus di kabupaten</p>
                </font>
                <font face="Langar" size="4">
                    <p class="pariwisata">Probolinggo yang akan memberikan kenangan terbaik dan tak</p>
                </font>
                <font face="Langar" size="4">
                    <p class="pariwisata">terlupakan bagi pengalaman berwisata anda.</p>
                </font>
            </div>
        </div>
    </section>

    <!-- about section start -->
    <section class="about" id="about">
        <div class="max-width">
            <h2 class="title">
                Gunung Bromo</h2>
            <div class="about-content">
                <div class="column left">
                    <img src="gunung.jpg" alt="">
                </div>
                <div class="column right">
                    <p>
                        Wisata Gunung Bromo adalah salah satu tempat wisata di indonesia yang menjadi favorit bagi wisatawan baik dalam negeri maupun luar negeri. Gunung Bromo terletak di Kabupaten Probolinggo. Gunung Bromo memiliki ketinggian sekitar 2392 mdpl. Memiliki kawah yang menjadi objek utama yang sering dikunjungi oleh wisatawan asing maupun lokal. Untuk sampai di bibir kawah, para wisatawan harus menaiki tangga yang cukup panjang. Gunung Bromo juga di kenal dengan sunrise dan sunsetnya. Tidak hanya pemandangan matahari terbit saja yang menjadi daya tarik utama Gunung Bromo, namun ada banyak sekali tempat wisata di sekitar Gunung Bromo yang jarang di explore oleh wisatawan.</p>
                </div>
            </div>
        </div><br>

        <div class="max-width">
            <h2 class="title">
                Pasir Berbisik</h2>
            <div class="about-content">
                <div class="column left">
                    <img src="pasir.jpg" alt="">
                </div>
                <div class="column right">
                    <p>
                        Bromo memang tempat yang sangat mengesankan, dan berwisata ke Bromo merupakan hal yang mengesankan di banding dengan berwisata ke tempat lain. Bromo adalah salah satu gunung yang ada di Jawa Timur yang sekaligus menjadi tempat tujuan wisata. Gunung Bromo ini menawarkan keindahan yang sangat luar biasa jika kita bandingkan dengan beberapa gunung lainnya.</p>
                    <p>Sehingga bukan hal yang mengherankan jika gunung Bromo menjadi salah satu tempat wisata yang selalu ramai dengan pengunjung. Gunung Bromo ini memiliki beberapa tempat wisata yang dapat anda nikmati, peristiwa alam yang membuat banyak orang tertarik untuk menikmatinya. Untuk menuju gunung Bromo ini anda harus melakukan perjalanan yang cukup jauh dan penuh perjuangan dengan jalan yang cukup terjal.</p>
                    <p>Salah satu tempat wisata yang ada di kawasan bromo adalah Pasir Berbisik Gunung Bromo. Pasir berbisik ini merupakan hamparan pasir yang sangat luas yang membentang di area Bromo. Pasir Berbisik ini berada disebelah timur kawah Bromo, yakni di ketinggian 2000m dari permukaan laut. Pasir berbisik juga sering kali dijadikan bagian dari paket wisata Bromo. Biasanya kunjungan ketempat ini dilakukan pada akhir dari sebuah trip setelah mengunjungi ke tiga obyek wisata lainya. Seperti, puncak penanjakan 1 melihat sunrise, kemudian melihat aktifitas kawah Bromo, menyaksikan panorama padang rumput savana.</p>
                </div>
            </div>
        </div><br>

        <div class="max-width">
            <h2 class="title">
                Gunung Argopura</h2>
            <div class="about-content">
                <div class="column left">
                    <img src="argo.jpg" alt="">
                </div>
                <div class="column right">
                    <p>
                        Gunung Argopuro memiliki trek pendakian terpanjang se-Jawa dengan total panjang pendakian sekitar 40 kilometer dan memiliki ketinggian 3088 mdpl. Gunung Argopuro atau disebut juga "Argopuro" adalah gunung api yang terletak di Jawa Timur tepatnya diperbatasan kabupaten Probolinggo, Situbondo, dan Bondowoso. Ada dua jalur pendakian menuju Gunung Argopuro yaitu pendakian via Bremi dan jalur pendakian via Baderan. Hal tersebut dikarenakan biasanya para pendaki memiliki start pendakian dan finish yang berbeda jalur. Selama perjalanan wisatawan disuguhkan dengan pemandangan indah di sepanjang jalur pendakian. Selama itu banyak wisata lain yang dapat kita jumpai di jalur pendakian Gunung Argopuro.</p>
                </div>
            </div>
        </div><br>

        <div class="max-width">
            <h2 class="title">
                Danau Taman Hidup</h2>
            <div class="about-content">
                <div class="column left">
                    <img src="danau.jpg" alt="">
                </div>
                <div class="column right">
                    <p>
                        Danau taman hidup berada dilembah Gunung Argopuro yang puncaknya memiliki ketinggian 30888Mdpl. Danau Taman Hidup ini memiliki daya tarik tersendiri karena merupakan tempat favorit Dewi Rengganis Putri dari kerajaan Majapahit. Jalur menuju danau ini tanpa ke puncak Argopuro, kita bisa memulai start dari desa Bermi, kecamatan Krucil, Kabupaten Probolinggo dengan berjalan kaki kurang lebih 6 jam. Wisata ini sangat direkomendasikan bagi mereka yang suka hiking, atau suka dengan hal hal yang menantang. Para wisatawan juga dapat mendirikan tenda di tepi danau apabila ingin menginap. Danau ini sangat cocok untuk mereka yang menginginkan suasana yang tenang dan damai. Agar lebih seru, ajaklah teman dan kerabat anda untuk beramai - ramai mengunjungi danau ini</p>
                </div>
            </div>
        </div><br>

        <div class="max-width">
            <h2 class="title">
                Pantai Bahak</h2>
            <div class="about-content">
                <div class="column left">
                    <img src="pantai.jpg" alt="">
                </div>
                <div class="column right">
                    <p>
                        Pantai Bahak berlokasi di Dusun Bahak, Desa Curahdringu, Kecamatan Tongas, Kabupaten Probolinggo. Disebut Pantai bahak, karena pantai ini berlokasi di Dusun Bahak, Desa Curahdringu, Kecamatan Tongas, Kabupaten Probolinggo. Pantai ini memang jarang terekspos, tapi tak luput dari pilihan wisatawan domestik karena keelokan proses terbenamnya matahari. Sembari menunggu proses alam pergantian siang dan malam, pengunjung biasanya menceburkan diri ke laut, mencari kerang, atau habitat laut lainnya yang bertebaran di sekitar pantai ini. Atau, sekadar menikmati aktivitas nelayan yang siap melaut. Rute untuk mencapai pantai ini cukup mudah. Dari arah Surabaya atau Banyuwangi, sesampainya di Kecamatan Tongas, Anda cukup bertanya RSUD Tongas. Lalu menyusuri jalan kecil ke arah utara. Anda juga harus melewati lintasan kereta api, dan MTS Negeri Tongas. Jika naik kendaraan roda 4, anda harus berjalan kaki sekitar 500 meter menuju pantai karena mobil tidak bisa masuk area pantai. Jalan menuju pantai hanya bisa dilewati dengan motor.</p>
                </div>
            </div>
        </div><br>

        <div class="max-width">
            <h2 class="title">
                Air Terjun Mandakaripura</h2>
            <div class="about-content">
                <div class="column left">
                    <img src="airterjun.jpg" alt="">
                </div>
                <div class="column right">
                    <p>
                        Air Terjun Madakaripura terlrtak tidak jauh dari Wisata Gunung Bromo, tepatnya berada di Desa Negororejo, Kecamatan Lumbang. Jaraknya sekitar 30 km atau sekitar 1 jam perjalanan dari pusat Kota Probolinggo. Air Terjun ini memiliki cerita mistis karena sejarah yang dimilikinya. Sejarah air terjun ini dulunya adalah tempat peristirahatan terakhir Mahapatih dari Majapahit yang bernama Gajah Mada, oleh karna itu air terjun ini disebut Air Terjun Madakaripura. Madakaripura sendiri merupakan tanah perdika yang diberikan raja Majapahit kala itu sebagai hadiah atas kerja keras Patih Gajah Mada dalam mempersatukan nusantara. Di pintu masuk Air Terjun Madakaripura terdapat patng Patih Gajah Mada.</p>
                    <p>Pemandangan alam yang disuguhkan Air Terjun Madakaripura sangat mempesona, dengan adanya air terjun tirai sepanjang jalan menuju air terjun utama. Air terjun tirai yang mempesona tersebut akibat pancuran air dari tebing - tebing yang membentuk seperti tirai. Begitu terkenalnya mitos Madakaripura ini sehingga air disana dianggap sakral dan konon katanya dapat menjadi awet muda. Karena mitos ini, Madakaripura disebut Tirta Sewana.</p>
                </div>
            </div>
        </div><br>

        <div class="max-width">
            <h2 class="title">
                Air Terjun Jaran Goyang</h2>
            <div class="about-content">
                <div class="column left">
                    <img src="goyang.jpg" alt="">
                </div>
                <div class="column right">
                    <p>
                        Destinasi wisata air terjun jaran goyang merupakan wisata baru di krucil kabupaten probolinggo pada tahun 2017 meskipun air terjun ini sudah lama keberadaannya namun baru diresmikan oleh Kepala Dinas Pemuda, Olahraga, Pariwisata, dan Budaya (Disporaparbud) Kabupaten Probolinggo.Ada cerita rakyat dibalik penggunaan nama Jaran Goyang itu. Penggunaan nama air terjun Jaran Goyang yang terletak di desa Guyangan, Kecamatan Krucil, Kabupaten Probolinggo ternyata tidak asal-asalan. Nama sebuah Guyangan itu merupakan tempat pemandian ratu. Yakni, Ratu Balgina. Berdasarkan cerita rakyat, konon air terjun Jaran Goyang itu merupakan aliran sungai Sironjengan.</p>
                    <p>Nama Jaran Goyang akhirnya menjadi nama air terjun dan dusun. Sementara Guyangan menjadi nama desa ini. Kalau nama air terjun Jaran Goyang itu sudah lama sejak zaman dulu, tidak tahu ceritanya gimana,” ungkap Hasyim, Kades Guyangan. Untuk menuju Guyangan tersebut, Ratu Balgina mengendarai kuda dengan dikawal beberapa pengawal kepercayaannya. “Guyangan tersebut merupakan pemandian Ratu Balgina dari sebuah kerajaan di daerah lain. Selain itu, di sekitar lokasi air terjun itu ada pohon jeruk yang buahnya berwarna oranye itu, ditanam oleh orang-orang Belanda di sekitaran jalan menuju air terjun. Pohon jeruk yang ada sejak puluhan tahun lalu. Konon, pohon tersebut sudah ada sejak zaman penjajahan Belanda. Di sepanjang pintu masuk hingga di sekitar lokasi air terjun ditanami sejumlah pohon. Pohon berbuah yang bisa dikonsumsi itu. Di antaranya pohon durian, alpukat, manggis, dan kelengkeng. “Pohon jeruk itu merupakan peninggalan zaman Belanda. Sekarang ada sekitar 7 pohon disekitar lokasi air terjun itu. Buahnya berwarna oranye,”</p>
                    <p>“Pohon-pohon itu merupakan salah satu penunjang daya tarik wisata air terjun Jaran Goyang. Ribuan pohon itu ditanam sejak 2 tahun terakhir, selama dua kali. Sekarang pohon-pohon berbuah itu tumbuh subur, sebagian di antaranya mulai berbuah,” Objek wisata air tejun yang didukung dengan agrowisatanya. Sehingga, ke depan diharapkan menjadi daya tarik tersendiri bagi pengunjung. Keberadaan sejumlah jenis pohon berbuah itu, merupakan salah satu bagian proyeksi Desa Guyangan dalam mengembangkan sebuah destinasi wisata baru di desa setempat. Pohon durian itu, kita tanam dengan jarak masing-masing 6 meter persegi,” ujarnya. “Untuk buah durian, sudah dilakukan 2 kali penanaman. Jumlahnya kini mencapai 400 pohon. Untuk 80 pohon di antaranya sudah berbuah.</p>
                    <p>Oleh-Oleh Dan Kuliner Buah Durian Khas Krucil Probolinggo Jika kamu berkunjung ke air terjun jaran goyang ini kamu dapat membawa oleh-oleh durian khas krucil, selain durian kamu juga dapat membawa oleh-oleh kopi, dan buah alpukat, manggis serta sayuran seperti kentang, gubis dan wortel karena krucil merupakan penghasil sayuran dan buah-buahan Kini di sekitar air terjun terdapat kedai kopi, warung makan dan kuliner lainnya. Selain memanfaatkan potensi desa, pembukaan wisata air terjun dan agrowisata itu, juga bertujuan untuk meningkatkan perekonomian dan lapangan pekerjaan bagi warga setempat.</p>
                </div>
            </div>
        </div><br>
    </section>

    <!-- teams section start -->
    <section class="teams" id="teams">
        <div class="max-width">
            <h2 class="title">
                Created</h2>
            <div class="carousel">
                <div class="card box">
                    <img src="ha.jpg" alt="">
                    <div class="text">
                        HAFID AFFAN WAHID</div>
                </div>
            </div>
        </div>
        </div>
    </section>

    <script src="javascript.js"></script>

    <!-- footer section start -->
    <footer>
        <span>Created By <a href="#">HAFID </a> | <span class="far fa-copyright"></span> 2020
        </span>
    </footer>

</body>

</html>